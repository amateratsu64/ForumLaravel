
@extends('layouts.gpt')

@section('header' , 'lista Todos os usuario')

@section('content')


<table>
    <th>
        <td>nome</td>
        <td>email</td>
    </th>
    <th>
    
        <td>nome</td>
        <td>email</td>
    </th>
 
</table>
    @endsection 