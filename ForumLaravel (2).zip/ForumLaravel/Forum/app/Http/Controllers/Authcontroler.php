<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Authcontroler extends Controller
{
    public function login_user(Request $request){
        if ($request->method() === 'GET'){
        return view('auth.login');
        }else{
            $username = $request->Username;
            $password = $request->Password;
            $credentials = $request->only('Username','Password');
            print($username . " - " . $password . "<br>");
            print_r($credentials);

            

        }
    }
}
