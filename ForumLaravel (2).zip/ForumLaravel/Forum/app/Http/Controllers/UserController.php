<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    

    public function listALLUsers(){
    //logica
    return view('user.listALLUser');   
    }

    public function Create_user(){
        return view('user.Create_user');
    }
    public function User_id(Request $request , $uid){
       print($uid);
       
        //return view('user.User_id');
    }
    public function edit_User_id(){

    }
    public function User_id_delet(){
    
    }

    
}

