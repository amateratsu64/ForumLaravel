


<?php $__env->startSection('header' , 'lista Todos os usuario'); ?>

<?php $__env->startSection('content'); ?>


<table>
    <th>
        <td>nome</td>
        <td>email</td>
    </th>
    <th>
    
        <td>nome</td>
        <td>email</td>
    </th>
 
</table>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.gpt3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\0031432412024\Downloads\ForumLaravel-main\ForumLaravel\Forum\resources\views/user/User_id.blade.php ENDPATH**/ ?>